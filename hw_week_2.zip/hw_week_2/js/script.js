// Week 1 HW
// function myMove() {
//   var elem = document.getElementById("animate");
//   var pos = 0;
//   var id = setInterval(frame, 5);
//   function frame() {
//     if (pos == 350) {
//       clearInterval(id);
//     } else {
//       pos++;
//       elem.style.top = pos + 'px';
//       elem.style.left = pos + 'px';
//     }
//   }
// }


// Week 2 HW 
var folded = new OriDomi(document.getElementsByClassName('paper')[0]);

initialPosition: .5

showInstruction: true

instructiontext: "Click and Drag"